__version__ = '0.8.7-dev'
# from HTMLr.core import HTMLObject
# from HTMLr.templates import Card, Combos, Table
