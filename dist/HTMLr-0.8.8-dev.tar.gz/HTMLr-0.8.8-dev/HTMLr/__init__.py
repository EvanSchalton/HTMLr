__version__ = '0.8.8-dev'
# from HTMLr.core import HTMLObject
# from HTMLr.templates import Card, Combos, Table
