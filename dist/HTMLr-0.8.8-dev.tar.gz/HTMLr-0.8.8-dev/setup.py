from distutils.core import setup

setup(
    name='HTMLr',
    version='0.8.8-dev',
    packages=['HTMLr',],
    license='Do whatever you want!',
    long_description=open('README.md').read(),
)
