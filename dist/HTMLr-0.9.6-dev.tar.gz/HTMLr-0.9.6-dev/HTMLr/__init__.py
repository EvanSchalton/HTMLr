__version__ = '0.9.6-dev'
# from HTMLr.core import HTMLObject
# from HTMLr.templates import Card, Combos, Table
