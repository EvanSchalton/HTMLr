from distutils.core import setup

setup(
    name='HTMLr',
    version='0.9.4-dev',
    packages=['HTMLr', 'HTMLr.templates'],
    license='Do whatever you want!',
    long_description=open('README.md').read(),
)
