from distutils.core import setup

setup(
    name='HTMLr',
    version='0.1dev',
    packages=['htmlr',],
    license='Do whatever you want!',
    long_description=open('README.md').read(),
)
