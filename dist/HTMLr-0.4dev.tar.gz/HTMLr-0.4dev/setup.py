from distutils.core import setup

setup(
    name='HTMLr',
    version='0.4dev',
    packages=['HTMLr',],
    license='Do whatever you want!',
    long_description=open('README.md').read(),
)
