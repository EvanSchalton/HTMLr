from distutils.core import setup

setup(
    name='HTMLr',
    version='0.9.0-dev',
    packages=['HTMLr',],
    license='Do whatever you want!',
    long_description=open('README.md').read(),
)
